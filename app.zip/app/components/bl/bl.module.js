'use strict';

angular.module('myApp.bl',[]);
